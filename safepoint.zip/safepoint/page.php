<?php
get_header();
while(have_posts()) {
  the_post(); ?>
  <section class="module bg-dark parallax" style="background-image: url(<?php echo get_theme_file_uri('assets/image/header.jpg');?>);height: 150px;" data-overlay="0.5">
         <div class="container">
             <div class="row">
                 <div class="col-md-12">
                     <div class="space" data-mb="100px">
                        <h1 class="text-center"><?php the_title();?></h1>
                          <div class="col-md-6 m-auto mt-0">
                          </div>
                     </div>
                 </div>
             </div>
         </div>
     </section>
     <section>
     	  <?php the_content(); ?>

     </section>
  
<?php }
get_footer();
 ?>
