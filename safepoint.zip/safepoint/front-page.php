<?php get_header();?>

<div class="wrapper pt-0">

  <section class="module-cover bg-dark parallax article-thumb" style="background-image: url(<?php echo get_theme_file_uri('assets/image/headerView.jpg');?>);" data-overlay="0.50" data-gradient="1">
<div class="container">
<div class="row">
  <div class="col-md-12 text-center">
      <div class="sidebar ">

          <form method="get" action="<?php echo esc_url(site_url('/')); ?>">
             <div class="input-group">
                 <input class="form-control" type="search" id="s" name="s" placeholder="Search for naturels phenomenons or disasters">
                <button class="btn btn-primary">Find</button>
            </div>
        </form>
</div>
      <h1 class="mb-4">We are here to<br><b>Save lifes</b>.</h1>
       
  </div>
  </div>

</div>
</div>

</section>


            <section class="module pt-0">
                <div class="container">
                    <div class="col-md-10 col-lg-10 m-auto">
                    <br>
                       <h1 class="text-center" id="present">Discover Safe Point</h1>
                       <p class="lead text-center">"SAFE POINT is a web application that allows you to have in advance: preventive measures to avoid natural disasters, alerts on the occurrence of a disaster. Our service propose both simples and practicals advices in real time and anywhere on natural disasters."
                      </p>
                    </div>
                </div>
            </section>

            <!-- Portfolio Carousel-->
             <section class="module pt-10 pb-0">
                
                <div class="container-fluid">
                    <div class="row row-portfolio" data-columns="4">
                        <!--div class="grid-sizer"></div-->
                        
                        <div class="portfolio-item packaging bg-dark">
                            <div class="portfolio-item-wrapper">
                                <div class="portfolio-item-img"><img src="<?php echo get_theme_file_uri('assets/image/carrousel/1.jpg');?>" alt=""></div>
                                <div class="portfolio-item-caption">
                                    <h5 class="portfolio-item-title">Volcanos</h5><span class="portfolio-item-subtitle serif"></span>
                                </div><a class="portfolio-item-link" href="portfolio-single-1.html"></a>
                            </div>
                        </div>
                        
                        <div class="portfolio-item packaging bg-dark">
                            <div class="portfolio-item-wrapper">
                                <div class="portfolio-item-img"><img src="<?php echo get_theme_file_uri('assets/image/carrousel/2.jpg');?>" alt=""></div>
                                <div class="portfolio-item-caption">
                                    <h5 class="portfolio-item-title">Tornados</h5><span class="portfolio-item-subtitle serif"></span>
                                </div><a class="portfolio-item-link" href="portfolio-single-1.html"></a>
                            </div>
                        </div>
                        <div class="portfolio-item packaging bg-dark">
                            <div class="portfolio-item-wrapper">
                                <div class="portfolio-item-img"><img src="<?php echo get_theme_file_uri('assets/image/carrousel/6.jpg')?>" alt=""></div>
                                <div class="portfolio-item-caption">
                                    <h5 class="portfolio-item-title">Floods</h5><span class="portfolio-item-subtitle serif"></span>
                                </div><a class="portfolio-item-link" href="portfolio-single-1.html"></a>
                            </div>
                        </div>
                        <div class="portfolio-item packaging bg-dark">
                            <div class="portfolio-item-wrapper">
                                <div class="portfolio-item-img"><img src="<?php echo get_theme_file_uri('assets/image/carrousel/7.jpg');?>" alt=""></div>
                                <div class="portfolio-item-caption">
                                    <h5 class="portfolio-item-title">Earthquakes</h5><span class="portfolio-item-subtitle serif"></span>
                                </div><a class="portfolio-item-link" href="portfolio-single-1.html"></a>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- Portfolio Carousel end-->

            <!-- Services-->
            <!-- Services-->
            <section class="module pt-0">
                <div class="container">
                <div class="col-md-10 col-lg-6 m-auto text-center">
                   <h1>Our Services</h1>
                </div>
                    <div class="row">
                            <div class="space" data-mt="60px"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <img src="<?php echo get_theme_file_uri('assets/image/phone/alert_design.png');?>">
                          </div>

                        <div class=" col-md-6 d-flex align-items-center col-lg-4">
                                       <div class="icon-box text-center">
                         <div class="icon-box-icon"><span class="ti-agenda"></span></div>
                                <div class="icon-box-title">
                                    <h6>Prevent</h6>
                                </div>
                                <div class="icon-box-content ">
                                    <p>We inform you in advance on your mobile phone of the occurrence of a natural disaster. The notification appears as +text sounds at the bottom of the red circle. Do not be afraid of the red indicator. At the bottom of this indicator is the date.</p>
                                </div>
                         </div>
                         </div>
                    </div>
                    <div class="row">
                        <div class=" col-md-6 d-flex align-items-center col-lg-4 mx-auto">
                                       <div class="icon-box text-center">
                              <div class="icon-box-icon"><span class="ti-alert"></span></div>
                                <div class="icon-box-title">
                                    <h6>Alert</h6>
                                </div>
                                <div class="icon-box-content">
                                    <p>SAFE POINT alerts you by SMS or direct voice calls before the event begins. The Alert comes as a text message on your door. Register to benefit from SAFE POINT's services!</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 mx-auto">
                            <img src="<?php echo get_theme_file_uri('assets/image/phone/notifi_design.png');?>">
                          </div>


                    </div>
                    <div class="row">
                        <div class="col-md-6 ">
                            <img src="<?php echo get_theme_file_uri('assets/image/phone/mesures_préventives.png');?>">
                          </div>

                        <div class=" col-md-6 d-flex align-items-center col-lg-4">
                                       <div class="icon-box text-center">
                              <div class="icon-box-icon"><span class="ti-bell"></span></div>
                                <div class="icon-box-title">
                                    <h6>Advices</h6>
                                </div>
                                <div class="icon-box-content">
                                    <p>When disaster strikes, SAFEPOINT is at your side by sending you advice directly to your mobile phone, we invite you to follow these tips to the letter.
                                    SAFE POINT; with you everywhere and everytime.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- Services end-->

            <!-- Testimonials-->
<section class="module bg-dark parallax" data-background="" data-overlay="1" data-gradient="1">
    <div class="container">
          <div class="col-md-10 col-lg-6 m-auto text-center mt-0">
                   <h1>Few Stats</h1>
                </div>
        <div class="row">
            <div class="col-md-3 text-center">
                <div class="counter">
                    <div class="counter-icon">/ year</span></div>
                    <div class="counter-number">
                        <h4>
                            <div class="counter-timer" data-from="0" data-to="410">410</div>
                        </h4>
                    </div>
                    <div class="counter-title">Disaster</div>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="counter">
                    <div class="counter-icon">/ year</span></div>
                    <div class="counter-number">
                        <h4>
                            <div class="counter-timer" data-from="0" data-to="220000000">220000000</div>
                        </h4>
                    </div>
                    <div class="counter-title">Persons affected</div>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="counter">
                    <div class="counter-icon">/ year</span></div>
                    <div class="counter-number">
                        <h4>
                            <div class="counter-timer" data-from="0" data-to="92000">92000</div>
                        </h4>
                    </div>
                    <div class="counter-title">Deads</div>
                </div>
            </div>
            <div class="col-md-3 text-center">
                <div class="counter">
                    <div class="counter-icon">/ year</div>
                    <div class="counter-number">
                        <h4>
                            <div class="counter-timer" data-from="0" data-to="113000000000">113000000000</div>
                        </h4>
                    </div>
                    <div class="counter-title">Coast</div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonials end-->




            <!-- Posts-->
            <section class="module divider-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-lg-6 m-auto text-center">
                            <h2>Our latest articles.</h2>
                            <p class="lead">Stay inform on latest naturels phenomenons and disasters features .</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="space" data-mb="60px"></div>
                        </div>
                    </div>
                    <?php 
            $homepagePosts = new WP_Query(array(
              'posts_per_page' => 6,
              'post_type' => 'post'
              ));
              while($homepagePosts->have_posts()) {
               $homepagePosts->the_post(); ?>
                    <div class="row card-masonry">
                         <div class="col-md-6">
                                
                                 <div class="card-body mb-10">
                                    <span class="card card-xl js-tilt mb-4">
                                  <?php the_post_thumbnail();?> 
                               </span>
                               <span>
                                    <?php echo get_the_category_list(', '); ?>
                                    <span class="m-l-3 m-r-6">|</span>
                                    </span>
                                    <?php the_time('j.n.Y'); ?>
                                     <h2 class="card-title"><a href="<?php the_permalink();?>" class="text-color"><?php the_title();?></a></h2>
                                     <?php echo wp_trim_words(get_the_content(), 30); ?>
                                 </div>
                                 
                                 <div class="card-footer"><a class="btn btn-dark" href="<?php the_permalink();?>">Read More &rarr;</a></div>
                         </div>
                      
                     </div>
                     <?php }
                     ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="space" data-mb="40px"></div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="text-center">
                                <p class="lead">Like what you see? <a href="<?php echo site_url('/blog');?>">See more posts &rarr;</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Posts end-->

            <!-- Callout-->
            <section class="module bg-dark parallax" style="background-image: url(<?php echo get_theme_file_uri('assets/image/header.jpg');?>)" data-overlay="0.5" id="contact">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="space" data-mb="100px"><h1 class="text-center">Contact us</h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 order-md-2 m-auto text-center">
                            <div class="space" data-mb="-100px"></div>
                            <div class="card card-xl z-index-10">
                                <div class="card-body">
                                    <form id="contact-form" method="post" novalidate>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input class="form-control " type="text" name="name" placeholder="Name" required="">
                                                    <p class="help-block text-danger"></p>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input class="form-control " type="email" name="email" placeholder="E-mail" required="">
                                                    <p class="help-block text-danger"></p>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input class="form-control " type="text" name="subject" placeholder="Subject" required="">
                                                    <p class="help-block text-danger"></p>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <textarea class="form-control " name="message" placeholder="Message" rows="12" required=""></textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <input class="btn btn-block btn-dark" type="submit" value="Send Message">
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Ajax response-->
                                    <div class="ajax-response text-center" id="contact-response"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Callout end-->

<?php get_footer();?>
