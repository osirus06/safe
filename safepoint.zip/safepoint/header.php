  <html>
    <head>
       <?php wp_head();?>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <meta name="description" content="">
       <meta name="author" content="">
     </head>

     <body data-spy="scroll" data-target="#navbar-1" data-offset="120">
<header class="site-header">
<nav class="navbar navbar-expand-lg navbar-dark navbar-logo-border fixed-top bg-white "><a class="navbar-brand" href="<?php  echo site_url('/');?>"><img src="<?php echo get_theme_file_uri('assets/image/logo.png');?>" width="120"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <!-- Right Nav-->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item "><a class="nav-link  text-dark" href="<?php echo site_url('/');?>">Home</a></li>
            <li class="nav-item"><a class="nav-link  text-dark" href="<?php echo site_url('/blog');?>">Blog</a></li>
            <li class="nav-item"><a class="nav-link  text-dark" href="<?php echo site_url('/donate');?>">Donate</a></li>
            <li class="nav-item"><a class="nav-link  text-dark" href="<?php echo site_url('/#contact');?>">Contact</a></li>
            <!-- <form class="form-inline"><a class="btn btn-sm btn-brand" href="sign-up.html">Sign up</a></form> -->
        </ul>
    </div>
    <p class="site-header__util">
        <?php if (is_user_logged_in()) { ?>
          <a class="btn btn--small btn-brand btn--with-photo" href="<?php echo wp_logout_url(); ?>"><span class="site_header__avatar"><?php echo get_avatar(get_current_user_id(), 60);?></span><span>Logout</span>
          </a>
      <?php } else { ?>
        <a class="btn btn--small btn-brand" href="<?php echo esc_url(site_url('/wp-signup.php')); ?>">Register</a><a class="btn btn--small btn-danger ml-5" href="<?php echo esc_url(site_url('/wp-login.php'));?>">Log in</a><?php } ?></p>
</nav>
</header>


            <!-- Hero-->
