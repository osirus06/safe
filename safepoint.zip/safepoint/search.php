<?php
get_header();
 ?>

 <div class="wrapper pt-0">
     <!-- Hero-->
     <section class="module bg-dark parallax" style="background-image: url(<?php echo get_theme_file_uri('assets/image/header.jpg');?>);" data-overlay="0.5">
         <div class="container">
             <div class="row">
                 <div class="col-md-12">
                     <div class="space" data-mb="100px">
                        <h1 class="text-center">Search results</h1>
                          <div class="col-md-6 m-auto mt-0">
                          </div>
                     </div>
                 </div>
             </div>
         </div>
     </section>

     <section class="module">
        <div class="container">
          <div class="row">
            <div class="col-lg-8">
                    <br>
                     <h2><?php
               echo'Result(s) for &ldquo;' . esc_html(get_search_query(false))  . '&rdquo;'
               ?></h2>
                    <div class="row card-mansory">
                        <div class="col-md-6">       
                          <?php 
                            if (have_posts()) {
                               while (have_posts()) {
                                 the_post();
                                 get_template_part('template-parts/content', get_post_type());
                                 ?>
                                <?php  } 
                                echo paginate_links();
                               } else {
                                echo '<h2>Any result find for &ldquo;' . esc_html(get_search_query(false))  . '&rdquo;</h2>';
                          }
                           ?>
                        </div>
                    </div>
                </div>
                <?php get_search_form();?>
                </div>
            </div>
     </section> 
