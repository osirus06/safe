<?php
get_header();
 ?>
 <div class="wrapper">
    <section class="module bg-dark parallax" data-background="assets/image/header.jpg" data-overlay="0.5">
              <div class="container">
                  <div class="row">
                      <div class="col-md-12">
                          <div class="space" data-mb="100px">
                          <h1 class="text-center">Donate</h1>
                          <div class="col-lg-4 col-md-6 m-auto">
                          <div class="mb-4">
                              <h5 class="text-color text-center   ">Make a subcription to save a life</h5>
                          </div>
                          <div class="mb-4">
                              <form method="post">
                              <div class="form-group">
                                      <input class="form-control" type="name" placeholder="Full Name">
                                  </div>
                                  <div class="form-group">
                                      <input class="form-control" type="email" placeholder="Email">
                                  </div>
                                  <div class="form-group">
                                      <select class="form-control" id="exampleFormControlSelect1" placeholder="Options">
                                        <option>$1 or more</option>
                                        <option>$5 or more</option>
                                        <option>$10 or more</option>
                                      </select>
                                    </div>
                                  <div class="form-group">
                                      <button class="btn btn-block btn-round btn-success" type="submit">Donate</button>
                                  </div>
                              </form>
                              <div class="text-center">
                              <img src="<?php echo get_theme_file_uri('assets/image/card');?>">
                              </div>
                          </div>

                      </div>
                          </div>
                      </div>
                  </div>
              </div>
      </section>

      <?php get_footer();?>
