<div class="col-lg-4">
                     <div class="sidebar">

                         <!-- Search widget-->
                         <aside class="widget widget-search">
                             <form method="get" action="<?php echo esc_url(site_url('/')); ?>">
                                 <div class="input-group">
                                      <input class="form-control" type="search"  id="s" name="s" placeholder="Search for naturels phenomenons or disasters">
                                      <button class="btn btn-primary">Find</button>
                                 </div>
                             </form>
                         </aside>

                        </div>
</div>