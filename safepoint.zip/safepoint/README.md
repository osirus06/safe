# Safe-Point
Application qui permet de donner des mesures préventives, d'alerter et de conseiller à l'avance en cas de catastrophes naturelles 
