<?php get_header();?>


<div class="wrapper pt-0">
        <section class="module bg-dark parallax" style="background-image: url(<?php echo get_theme_file_uri('assets/image/header.jpg');?>);" data-overlay="0.5">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="space" data-mb="100px">
                            <h1 class="text-center">Sign Up</h1>
                            <div class="col-lg-4 col-md-6 m-auto">
                            <div class="mb-4">
                                <h5 class="text-color text-center">Register your account</h5>
                            </div>
                            <div class="mb-4">
                                <form method="post">
                                	<div class="form-group">
                                        <input class="form-control" type="text" placeholder="Full Name">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" type="email" placeholder="Email">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" type="password" placeholder="Pasword">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" type="text" placeholder="Phone Number">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" type="text" placeholder="Contry">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" type="text" placeholder="City">
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-primary" type="submit">Sign Up</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>


                

<?php get_footer();?>