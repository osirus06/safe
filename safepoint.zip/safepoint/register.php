<?php include('menu.html'); ?>
        <div class="wrapper pt-0">
            <section class="module bg-dark text-center" data-background="assets/image/header.jpg" data-overlay="1" data-gradient="1">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                               <h1 class="text-center">Sign Up</h1>
                                 <div class="col-md-6 m-auto mt-0">
                                    <form method="post">

                                       <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                          <li class="nav-item"><a class="nav-link active text-color" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Basics Informations</a>
                                         </li>
                                          <li class="nav-item"><a class="nav-link text-color" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Additionals Informations</a>
                                        </li>
                                       </ul>

                      <div class="tab-content" id="pills-tabContent">

                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                            <div class="form-group">
                                        <input class="form-control" type="text" placeholder="Fisrt Name" required>
                            </div>

                            <div class="form-group">
                                        <input class="form-control" type="text" placeholder="Surname" required>
                            </div>

                            <div class="form-group">
                                        <input class="form-control" type="email" placeholder="E-mail" required>
                            </div>

                            <div class="form-group">
                                        <input class="form-control" type="password" placeholder="Pasword" required>
                            </div>

                            <div class="form-group">
                                        <input class="form-control" type="password" placeholder="Confirm password" required>
                            </div>

                           </div>

                            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                              <div class="form-group">
                                        <input class="form-control" type="text" placeholder="Phone Number" required>
                              </div>

                              <div class="form-group">
                                        <input class="form-control" type="text" placeholder="Country" required>
                              </div>

                              <div class="form-group">
                                        <input class="form-control" type="text" placeholder="City" required>
                              </div>
                                    <!--div class="form-group">
                                        <button class="btn btn-block btn-round custom-blue" type="submit">Sign Up</button>
                                    </div-->
                                    <!-- Button trigger modal -->
                                     <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Sign Up</button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                          <div class="modal-content">
                                            <div class="modal-header">
                                              <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                              </button>
                                            </div>
                                            <div class="modal-body">
                                              <span class="text-dark">Sign up succeed</span>
                                            </div>
                                            <div class="modal-footer">
                                              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                              <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                                            </div>
                                          </div>
                                        </div>
                                        </div>
                                  </div>
  
                                 </div>
                                </form>
                            </div>
                    </div>
                </div>
                </div>
            </section>
                
                
            <!-- Footer-->

            <?php include('footer.html'); ?>