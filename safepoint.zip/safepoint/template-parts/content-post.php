                                 <div class="card-body mb-10">
                                    <span class="card card-xl js-tilt mb-4">
                                  <?php the_post_thumbnail();?> 
                               </span>
                               <span>
                                    <?php echo get_the_category_list(', '); ?>
                                    <span class="m-l-3 m-r-6">|</span>
                                    </span>
                                    <?php the_time('j.n.Y'); ?>
                                     <h2 class="card-title"><a href="#" class="text-color"><?php the_title();?></a></h2>
                                     <?php echo wp_trim_words(get_the_content(), 30); ?>
                                 </div>
                                 
                                 <div class="card-footer"><a class="btn btn-dark" href="<?php the_permalink();?>">Read More &rarr;</a></div>