
            <!-- Footer-->

            <!-- Footer end-->
            <footer class="footer bg-dark">
                <div class="footer-widgets">
                    <div class="container">
                        <div class="row">
                           <div class="col-md-3 col-sm-6">
                              
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <aside class="widget">
                                    <div class="widget-title">
                                        <h6>Utils Links</h6>
                                    </div>
                                    <ul>
                                        <li><a href="<?php echo site_url('/blog');?>">Blog</a></li>
                                        <li><a href="<?php echo site_url('/donate');?>">Donate</a></li>
                                        <li><a href="<?php echo site_url('/#contact');?>">Contact</a></li>
                                        
                                    </ul>
                                </aside>
                            </div>
                            <div class="col-md-3 col-sm-6">
                                <aside class="widget">
                                    <div class="widget-title">
                                        <h6>Account</h6>
                                    </div>
                                    <ul>
                                      <?php if (is_user_logged_in()) { ?>
                                        <li><a href="<?php echo wp_logout_url(); ?>"><span class="site_header__avatar"><?php echo get_avatar(get_current_user_id(), 30);?></span><span>Logout</span></a></li>
                                         <?php } else { ?>
                                        <li><a href="<?php echo esc_url(site_url('/wp-signup.php')); ?>">Register</a></li>
                                        <li><a href="="<?php echo esc_url(site_url('/wp-login.php'));?>">Log In</a><?php } ?></li>
                                      
                                    </ul>
                                </aside>
                            </div>
                            <div class="col-md-3 col-sm-6">
                              
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bar">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="copyright">
                                    <p>&copy; Copyright 2018, Safe Point, All Rights Reserved.</p>
                                </div>
                            </div>
                            <div class="col-md-6 d-none d-md-block">
                                <ul class="list-unstyled list-inline mb-0 pb-0 text-right">
                                    <li class="list-inline-item"><img src="assets/images/payments/if_visa.png" alt=""></li>
                                    <li class="list-inline-item"><img src="assets/images/payments/if_paypal.png" alt=""></li>
                                    <li class="list-inline-item"><img src="assets/images/payments/if_mastercard.png" alt=""></li>
                                    <li class="list-inline-item"><img src="assets/images/payments/if_discover.png" alt=""></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>

        <!-- To top button--><a class="scroll-top" href="#top"><i class="ti-angle-up"></i></a>
    </body>
</html>
