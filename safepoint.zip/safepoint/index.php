<?php
get_header();
 ?>

 <div class="wrapper pt-0">
     <!-- Hero-->
     <section class="module bg-dark parallax" style="background-image: url(<?php echo get_theme_file_uri('assets/image/header.jpg');?>);" data-overlay="0.5">
         <div class="container">
             <div class="row">
                 <div class="col-md-12">
                     <div class="space" data-mb="100px">
                        <h1 class="text-center">Blog</h1>
                          <div class="col-md-6 m-auto mt-0">
                          </div>
                     </div>
                 </div>
             </div>
         </div>
     </section>
     <!-- Hero end-->

     <!-- Posts-->
     <section class="module">
         <div class="container">
             <div class="row">
                 <div class="col-lg-8">
                   <?php while (have_posts()) { the_post();?>
                     <div class="row card-masonry">
                         <div class="col-md-6">
                                
                                 <div class="card-body mb-10">
                                    <span class="card card-xl js-tilt mb-4">
                                  <?php the_post_thumbnail();?> 
                               </span>
                               <span>
                                    <?php echo get_the_category_list(', '); ?>
                                    <span class="m-l-3 m-r-6">|</span>
                                    </span>
                                    <?php the_time('j.n.Y'); ?>
                                     <h2 class="card-title"><a href="<?php the_permalink();?>" class="text-color"><?php the_title();?></a></h2>
                                     <?php echo wp_trim_words(get_the_content(), 30); ?>
                                 </div>
                                 
                                 <div class="card-footer"><a class="btn btn-dark" href="<?php the_permalink();?>">Read More &rarr;</a></div>
                         </div>
                      
                     </div>
                      <?php }
                       echo paginate_links(); ?>
                 </div>
                 <div class="col-lg-4">
                     <div class="sidebar">

                         <!-- Search widget-->
                         <aside class="widget widget-search">
                             <form method="get" action="<?php echo esc_url(site_url('/')); ?>">
                                 <div class="input-group">
                                      <input class="form-control" type="search"  id="s" name="s" placeholder="Search for naturels phenomenons or disasters">
                                      <button class="btn btn-primary">Find</button>
                                 </div>
                             </form>
                         </aside>

                         <!-- Categories widget-->
                         <aside class="widget widget-categories">
                             <div class="widget-title">
                                 <h2>Categories</h2>
                             </div>
                              <ul>
                                 <li><a href="<?php echo site_url('/category/volcans') ?>" class="btn btn-danger">Volcanos <span class="float-right"></span></a></li>
                                 <li><a href="<?php echo site_url('/category/seismes') ?>" class="btn btn-success">Earthquakes <span class="float-right"></span></a></li>
                                 <li><a href="<?php echo site_url('/category/tornade') ?>" class="btn btn-info">Tornados <span class="float-right"></span></a></li>
                                 <li><a href="<?php echo site_url('/category/inondations') ?>" class="btn btn-dark">Floods<span class="float-right"></span></a></li>
                                 <li><a href="<?php echo site_url('/category/nature_space') ?>" class="btn btn btn-primary">Naturals phenomena of the Earth and Space<span class="float-right"></span></a></li>
                             </ul>
                         </aside>

                        

                     </div>
                 </div>
             </div>
         </div>
     </section>

 <?php
get_footer();
  ?>
