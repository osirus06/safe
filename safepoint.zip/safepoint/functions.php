<?php

function safepoint_files(){
	//CSS
  wp_enqueue_style('template-style', get_theme_file_uri('/assets/css/template.min.css'));
  wp_enqueue_style('plugins', get_theme_file_uri('/assets/css/plugins.min.css'));
  wp_enqueue_style('safepoint_main_style', get_stylesheet_uri());
    //JS
  wp_enqueue_script('bootstrap', get_theme_file_uri('/assets/js/bootstrap/bootstrap.min.js'), NULL, '1.0', true);
  wp_enqueue_script('popper', get_theme_file_uri('/assets/js/bootstrap/popper.min.js'), NULL, '1.0', true);
  wp_enqueue_script('custom', get_theme_file_uri('/assets/js/custom/custom.min.js'), NULL, '1.0');
  wp_enqueue_script('jquery', get_theme_file_uri('/assets/js/custom/jquery-3.2.1.min.js'), NULL, '1.0', true);
  wp_enqueue_script('plugins', get_theme_file_uri('/assets/js/custom/plugins.min.js'), NULL, '1.0', true);
}

add_action('wp_enqueue_scripts', 'safepoint_files');

 function safepoint_features(){
        add_theme_support('title-tag');
 }

 add_action('after_setup_theme', 'safepoint_features');

add_theme_support('post-thumbnails');

//add_action('pre_get_posts', 'safepoint_queries');

//redirect suscriber accounts out of admin onto homepage


function my_login_redirect( $url, $request, $user ){
if( $user && is_object( $user ) && is_a( $user, 'WP_User' ) ) {
if( $user->has_cap( 'administrator') or $user->has_cap( 'author')) {
$url = admin_url();
} else {
$url = home_url('/');
}
}
return $url;
}
add_filter('login_redirect', 'my_login_redirect', 10, 3 );

//customize login screen
add_filter('login_headerurl', 'ourHeaderUrl');

function ourHeaderUrl() {
	return esc_url(site_url('/'));

}

add_action('login_enqueue_scripts', 'ourLoginCSS');

function ourLoginCSS() {
     wp_enqueue_style('template-style', get_theme_file_uri('/assets/css/template.min.css'));
}